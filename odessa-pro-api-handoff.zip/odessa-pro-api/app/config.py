from pathlib import Path

UPLOAD_DIR = Path("uploads")
SUMMARY_DIR = Path("summaries")
UPLOAD_DIR.mkdir(exist_ok=True)
SUMMARY_DIR.mkdir(exist_ok=True)
