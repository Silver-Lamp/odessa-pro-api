# Odessa Pro API

This is the modular version of the Odessa Pro backend built with FastAPI.

## Structure
- `app/routes`: All route definitions
- `app/core`: Core logic like summarization and storage
- `app/models`: Pydantic schemas
- `app/config.py`: Directories and settings
- `uploads/` and `summaries/`: Runtime folders for file and output

## Usage

### Local
```bash
python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt
uvicorn app.main:app --reload
```

### Docker
```bash
docker build -t odessa-pro-api .
docker run -p 8000:8000 odessa-pro-api
```
